import React from 'react';
import { Container } from 'react-bootstrap';

const containerStyles = {
  textAlign: 'center', // Pusatkan teks
  paddingTop: '50px', // Atur jarak atas sesuai keinginan Anda
};

const headingStyles = {
  fontSize: '24px', // Ukuran font
  fontWeight: 'bold', // Teks tebal
  color: 'blue', // Warna teks
};

const paragraphStyles = {
  fontSize: '16px', // Ukuran font
};

const Home = () => {
  return (
    <Container style={containerStyles}>
      <h1 style={headingStyles} >Selamat Datang di Halaman Home</h1>
      <p style={paragraphStyles}>Ini adalah konten halaman Home Anda.</p>
    </Container>
  );
};

export default Home;